export function KCPpageA2() {
  return (
    <>
      <h1>KCP Page A2</h1>
    </>
  );
}
