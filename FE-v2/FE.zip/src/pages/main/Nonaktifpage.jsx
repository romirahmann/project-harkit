export function Nonaktifpage() {
  return (
    <>
      <h1>Nonaktif Page</h1>
    </>
  );
}
